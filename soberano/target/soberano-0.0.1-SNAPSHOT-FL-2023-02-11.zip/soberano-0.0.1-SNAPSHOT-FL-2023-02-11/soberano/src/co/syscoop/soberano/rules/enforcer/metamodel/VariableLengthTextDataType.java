package co.syscoop.soberano.rules.enforcer.metamodel;

public class VariableLengthTextDataType extends DataTypeElement {

}
