package co.syscoop.soberano.rules.enforcer.metamodel;

public class ImpliedByObjectification extends RefElement {

}
