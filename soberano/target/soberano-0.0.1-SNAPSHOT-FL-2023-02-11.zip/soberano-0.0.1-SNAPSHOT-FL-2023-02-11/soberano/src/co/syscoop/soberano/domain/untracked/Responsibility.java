package co.syscoop.soberano.domain.untracked;

public class Responsibility extends DomainObject {

	public Responsibility(Integer id, String name) {
		super(id, name);
	}
}
