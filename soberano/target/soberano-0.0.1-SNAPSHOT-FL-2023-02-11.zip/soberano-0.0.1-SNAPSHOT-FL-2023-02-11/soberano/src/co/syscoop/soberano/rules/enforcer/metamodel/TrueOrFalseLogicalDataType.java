package co.syscoop.soberano.rules.enforcer.metamodel;

public class TrueOrFalseLogicalDataType extends DataTypeElement {

}
