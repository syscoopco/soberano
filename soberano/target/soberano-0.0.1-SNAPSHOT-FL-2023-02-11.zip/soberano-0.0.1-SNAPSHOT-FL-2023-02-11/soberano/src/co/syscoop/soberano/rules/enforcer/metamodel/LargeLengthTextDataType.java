package co.syscoop.soberano.rules.enforcer.metamodel;

public class LargeLengthTextDataType extends DataTypeElement  {

}
