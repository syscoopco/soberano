package co.syscoop.soberano.rules.enforcer.metamodel;

public class AutoTimestampTemporalDataType extends DataTypeElement {

}
