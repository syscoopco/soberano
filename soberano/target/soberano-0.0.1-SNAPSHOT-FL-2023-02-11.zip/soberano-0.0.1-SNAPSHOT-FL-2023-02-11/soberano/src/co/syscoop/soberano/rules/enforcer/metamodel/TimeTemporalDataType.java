package co.syscoop.soberano.rules.enforcer.metamodel;

public class TimeTemporalDataType extends DataTypeElement {

}
