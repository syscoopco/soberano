package co.syscoop.soberano.rules.enforcer.metamodel;

public class DateTemporalDataType extends DataTypeElement {

}
