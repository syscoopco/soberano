package co.syscoop.soberano.rules.enforcer.metamodel;

public class DerivationNote extends ModelElement {

	//xml attributes
	private String body;

	//methods
	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}
}
