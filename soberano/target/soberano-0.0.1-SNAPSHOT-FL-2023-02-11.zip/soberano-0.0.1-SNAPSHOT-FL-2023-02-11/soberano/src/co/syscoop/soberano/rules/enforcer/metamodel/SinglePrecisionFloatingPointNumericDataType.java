package co.syscoop.soberano.rules.enforcer.metamodel;

public class SinglePrecisionFloatingPointNumericDataType  extends DataTypeElement {

}
