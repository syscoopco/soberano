package co.syscoop.soberano.domain.untracked;

public class Authority extends DomainObject {

	public Authority(Integer id, String name) {
		super(id, name);
	}
}
