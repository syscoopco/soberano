package co.syscoop.soberano.rules.enforcer.metamodel;

public class LargeLengthRawDataDataType extends DataTypeElement{

}
