package co.syscoop.soberano.rules.enforcer.metamodel;

import co.syscoop.soberano.helper.xml.SimpleElement;

public class CustomFormatString extends SimpleElement{

}
