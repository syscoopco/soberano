package co.syscoop.soberano.rules.enforcer.metamodel;

public class SignedSmallIntegerNumericDataType extends DataTypeElement{

}
