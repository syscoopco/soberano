package co.syscoop.soberano.rules.enforcer.metamodel;

public class PreferredIdentifierFor extends RefElement {

	
}
