package co.syscoop.soberano.beans;

public class WebApplicationProperties {
	
	private String vocabulary = "soberano";

	public String getVocabulary() {
		return vocabulary;
	}

	public void setVocabulary(String vocabulary) {
		this.vocabulary = vocabulary;
	}
}
