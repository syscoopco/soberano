package co.syscoop.soberano.rules.enforcer.metamodel;

public class DataTypeElement extends ModelElement {

}
