package co.syscoop.soberano.rules.enforcer.metamodel;

public class SupertypeMetaRole extends Role{

}
