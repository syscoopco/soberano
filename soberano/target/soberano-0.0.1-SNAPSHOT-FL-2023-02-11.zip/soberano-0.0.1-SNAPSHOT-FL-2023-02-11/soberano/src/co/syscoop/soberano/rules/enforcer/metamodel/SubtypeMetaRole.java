package co.syscoop.soberano.rules.enforcer.metamodel;

public class SubtypeMetaRole extends Role {

}
