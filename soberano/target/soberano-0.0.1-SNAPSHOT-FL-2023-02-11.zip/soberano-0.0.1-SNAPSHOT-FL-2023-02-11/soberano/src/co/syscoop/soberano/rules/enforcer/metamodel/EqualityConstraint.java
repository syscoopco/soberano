package co.syscoop.soberano.rules.enforcer.metamodel;

public class EqualityConstraint extends SubsetOrExclusionConstraint {

}
