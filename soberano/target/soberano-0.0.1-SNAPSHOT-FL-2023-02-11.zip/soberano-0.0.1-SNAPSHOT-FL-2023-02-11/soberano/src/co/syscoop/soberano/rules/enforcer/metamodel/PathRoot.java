package co.syscoop.soberano.rules.enforcer.metamodel;

public class PathRoot extends RefElement {

}
