package co.syscoop.soberano.rules.enforcer.metamodel;

public class UnsignedLargeIntegerNumericDataType extends DataTypeElement{

}
