package co.syscoop.soberano.rules.enforcer.metamodel;

public class SubsetConstraint extends SubsetOrExclusionConstraint {

}
